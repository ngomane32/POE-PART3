/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.mycompany.finalpart3;

import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author lab_services_student
 */
public class TaskIT {
    
    public TaskIT() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of addTask method, of class Task.
     */
    @Test
    public void testAddTask() {
        System.out.println("addTask");
        int count = 0;
        Task instance = new Task();
        instance.addTask(count);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of returnTotalHours method, of class Task.
     */
    @Test
    public void testReturnTotalHours() {
        System.out.println("returnTotalHours");
        Task instance = new Task();
        int expResult = 0;
        int result = instance.returnTotalHours();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of searchTask method, of class Task.
     */
    @Test
    public void testSearchTask() {
        System.out.println("searchTask");
        String taskName = "";
        Task instance = new Task();
        String expResult = "";
        String result = instance.searchTask(taskName);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of deleteTask method, of class Task.
     */
    @Test
    public void testDeleteTask() {
        System.out.println("deleteTask");
        String taskName = "";
        Task instance = new Task();
        String expResult = "";
        String result = instance.deleteTask(taskName);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of displayLongest method, of class Task.
     */
    @Test
    public void testDisplayLongest() {
        System.out.println("displayLongest");
        Task instance = new Task();
        String expResult = "";
        String result = instance.displayLongest();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of searchDeveloper method, of class Task.
     */
    @Test
    public void testSearchDeveloper() {
        System.out.println("searchDeveloper");
        String devName = "";
        Task instance = new Task();
        String expResult = "";
        String result = instance.searchDeveloper(devName);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of updateTaskStatus method, of class Task.
     */
    @Test
    public void testUpdateTaskStatus() {
        System.out.println("updateTaskStatus");
        String taskName = "";
        String status = "";
        Task instance = new Task();
        instance.updateTaskStatus(taskName, status);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getDeveloper method, of class Task.
     */
    @Test
    public void testGetDeveloper() {
        System.out.println("getDeveloper");
        Task instance = new Task();
        List<String> expResult = null;
        List<String> result = instance.getDeveloper();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getTaskNames method, of class Task.
     */
    @Test
    public void testGetTaskNames() {
        System.out.println("getTaskNames");
        Task instance = new Task();
        List<String> expResult = null;
        List<String> result = instance.getTaskNames();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getTaskID method, of class Task.
     */
    @Test
    public void testGetTaskID() {
        System.out.println("getTaskID");
        Task instance = new Task();
        List<String> expResult = null;
        List<String> result = instance.getTaskID();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getStatus method, of class Task.
     */
    @Test
    public void testGetStatus() {
        System.out.println("getStatus");
        Task instance = new Task();
        List<String> expResult = null;
        List<String> result = instance.getStatus();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getDuration method, of class Task.
     */
    @Test
    public void testGetDuration() {
        System.out.println("getDuration");
        Task instance = new Task();
        List<Integer> expResult = null;
        List<Integer> result = instance.getDuration();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
