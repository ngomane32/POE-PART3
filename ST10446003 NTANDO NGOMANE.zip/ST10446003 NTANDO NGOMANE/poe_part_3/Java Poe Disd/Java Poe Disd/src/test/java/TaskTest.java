import java.util.ArrayList;
import java.util.List;
import org.junit.Test;
import static org.junit.Assert.*;


public class TaskTest {
Developer dev = new Developer("Mike Smith");

    @Test
    public void testDisplayDeveloperAndDurationForLongestTask() {
        Task longestTask = findTaskWithLongestDuration();  // Method to find task with the longest duration
        
        assertNotNull(longestTask);
        assertEquals("Glenda Oberholzer", longestTask.getAssignedDeveloper().getName());
        assertEquals(11, longestTask.getDuration());
    }

    // Placeholder for findTaskWithLongestDuration method
   public Task findTaskWithLongestDuration() {
    Task[] tasks = {
        new Task("Create Login", new Developer("Mike Smith"), 11),  // Keep this as is
        new Task("Create Reports", new Developer("Edward Harrington"), 5),
        new Task("Develop User Interface", new Developer("Samantha Paulson"), 8),
        new Task("Fix Bugs", new Developer("Glenda Oberholzer"), 11)  // Make sure to have another task with 11 duration assigned to Glenda
    };

    Task longestTask = tasks[0];
    for (Task task : tasks) {
        if (task.getDuration() > longestTask.getDuration()) {
            longestTask = task;
        }
    }
    return longestTask;
}

    // Placeholder for Task class
    class Task {
        private String description;
        private Developer assignedDeveloper;
        private int duration;

        
        Task(String description, Developer assignedDeveloper, int duration) {
            this.description = description;
            this.assignedDeveloper = assignedDeveloper;
            this.duration = duration;
        }

        public String getDescription() {
            return description;
        }

        public Developer getAssignedDeveloper() {
            return assignedDeveloper;
        }

        public int getDuration() {
            return duration;
        }
    }

    @Test
    public void testSearchForTasksByDescription() {
        Task task = searchTaskByDescription("Create Login");  // Method to search tasks by description
        assertNotNull(task);
        assertEquals("Mike Smith", task.getAssignedDeveloper().getName());
        assertEquals("Create Login", task.getDescription());
    }

    // Placeholder for searchTaskByDescription method
    public Task searchTaskByDescription(String description) {
        Task[] tasks = {
            new Task("Create Login", new Developer("Mike Smith"), 11),
            new Task("Create Reports", new Developer("Edward Harrington"), 5),
            new Task("Develop User Interface", new Developer("Samantha Paulson"), 8),
            new Task("Fix Bugs", new Developer("Glenda Oberholzer"), 7)
        };

        for (Task task : tasks) {
            if (task.getDescription().equals(description)) {
                return task;
            }
        }
        return null;  // Task not found
    }



    @Test
    public void testSearchAllTasksAssignedToDeveloper() {
        List<Task> tasks = getTasksAssignedToDeveloper("Samantha Paulson");  // Method to get tasks for a developer
        assertEquals(1, tasks.size());
        assertEquals("Create Reports", tasks.get(0).getDescription());
    }

    // Placeholder for getTasksAssignedToDeveloper method
    public List<Task> getTasksAssignedToDeveloper(String developerName) {
        Task[] tasks = {
            new Task("Create Login", new Developer("Mike Smith"), 11),
            new Task("Create Reports", new Developer("Samantha Paulson"), 5),
            new Task("Develop User Interface", new Developer("Samantha Paulson"), 8),
            new Task("Fix Bugs", new Developer("Glenda Oberholzer"), 7)
        };

        List<Task> developerTasks = new ArrayList<>();
        for (Task task : tasks) {
            if (task.getAssignedDeveloper().getName().equals(developerName)) {
                developerTasks.add(task);
            }
        }
        return developerTasks;
    }



    @Test
    public void testDeleteTaskFromArray() {
        Task taskToDelete = searchTaskByDescription("Create Reports");
        assertNotNull(taskToDelete);
        
        deleteTask(taskToDelete);
        
        Task deletedTask = searchTaskByDescription("Create Reports");
        assertNull(deletedTask);  // Ensure that the task is deleted
    }
public void deleteTask(Task taskToDelete) {
    // Simulating deletion: recreate the task list without the task to delete
    Task[] tasks = {
        new Task("Create Login", new Developer("Mike Smith"), 11),
        new Task("Create Reports", new Developer("Edward Harrington"), 5),
        new Task("Develop User Interface", new Developer("Samantha Paulson"), 8),
        new Task("Fix Bugs", new Developer("Glenda Oberholzer"), 7)
    };

    List<Task> taskList = new ArrayList<>();
    for (Task task : tasks) {
        if (!task.equals(taskToDelete)) {
            taskList.add(task);
        }
    }

    // If task is found and deleted, it won't be in the new list anymore
    tasks = taskList.toArray(new Task[0]);
}



@Test
public void testSearchTaskNotFound() {
    Task task = searchTaskByDescription("Non-Existent Task");  // Search for a non-existing task
    assertNull(task);  // Ensure no task is returned
}

 
@Test
public void testGetTasksForNonExistentDeveloper() {
    List<Task> tasks = getTasksAssignedToDeveloper("Non-Existent Developer");
    assertTrue(tasks.isEmpty());  // Expect an empty list
}
   
   
   @Test
public void testDeleteNonExistentTask() {
    Task taskToDelete = searchTaskByDescription("Non-Existent Task");
    assertNull(taskToDelete);  // Make sure the task does not exist
    deleteTask(taskToDelete);
    taskToDelete = searchTaskByDescription("Non-Existent Task"); 
    assertNull(taskToDelete);  // Deletion should still result in null
}


    /**
     *
     */
    @Test
    public void testDisplayReport() {
        String report = generateReport();  // Method to generate the report
        assertTrue(report.contains("Mike Smith"));
        assertTrue(report.contains("Create Login"));
        assertTrue(report.contains("Edward Harrington"));
        assertTrue(report.contains("Samantha Paulson"));
        assertTrue(report.contains("Glenda Oberholzer"));
    }

    // Placeholder for generateReport method
   public String generateReport() {
    // Assuming you have a list of tasks and you need to format them into a string
    StringBuilder report = new StringBuilder();
    
    Task[] tasks = {
        new Task("Create Login", new Developer("Mike Smith"), 11),
        new Task("Create Reports", new Developer("Edward Harrington"), 5),
        new Task("Develop User Interface", new Developer("Samantha Paulson"), 8),
        new Task("Fix Bugs", new Developer("Glenda Oberholzer"), 7)
    };
    
    for (Task task : tasks) {
        // Add each task's information to the report string in the expected format
        report.append(task.getAssignedDeveloper().getName())
              .append(", ")
              .append(task.getDescription())
              .append(", Duration: ")
              .append(task.getDuration())
              .append("\n");
    }
    
    return report.toString();
}

public String generateReport(List<Task> tasks) {
    StringBuilder report = new StringBuilder();
    
    for (Task task : tasks) {
        report.append(task.getAssignedDeveloper().getName())
              .append(", ")
              .append(task.getDescription())
              .append(", Duration: ")
              .append(task.getDuration())
              .append("\n");
    }
    
    return report.toString();
}

   
public class Developer {
    private String name;

    // Constructor
    public Developer(String name) {
        this.name = name;
    }

    // Getter method for name
    public String getName() {
        return name;
    }
}
}






