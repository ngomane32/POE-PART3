/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.finalpart3;
import javax.swing.JOptionPane;
/**
 *
 * @author lab_services_student
 */
public class Login {
 private String username, password, name, surname;

    public String getUsername() {
        return this.username;
    }
    public String getPassword() {
        return this.password;
    }
    public String getName() {
        return this.name;
    }
    public String getSurname() {
        return this.surname;
    }
    public boolean setUsername(String username) {
        this.username = username;
        boolean usernameIsValid = checkUserName();

        if (usernameIsValid) {
            JOptionPane.showMessageDialog(null, "Username successfully captured.", "Username", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Username is not correctly formatted. Please ensure that your username contains an underscore and is no more than 5 characters in length.", "Invalid Username", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        return true;
    }

    public boolean setPassword(String password) {
        this.password = password;
        boolean passwordIsValid = checkPasswordComplexity();

        if (passwordIsValid) {
            JOptionPane.showMessageDialog(null, "Password successfully captured.", "Password", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Password is not correctly formatted. Please ensure that the password contains at least 8 characters.", "Invalid Password", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        return true;
    }

    public void setFirstName() {
        this.name = JOptionPane.showInputDialog(null, "Please enter your name:", "First Name", JOptionPane.PLAIN_MESSAGE);
    }

    public void setLastName() {
        this.surname = JOptionPane.showInputDialog(null, "Please enter your surname:", "Last Name", JOptionPane.PLAIN_MESSAGE);
    }

    public String registerUser() {
        String username = JOptionPane.showInputDialog(null, "Please enter your username:", "Username", JOptionPane.PLAIN_MESSAGE);
        boolean isUsernameValid = setUsername(username);

        if (!isUsernameValid) {
            return "\nThe username is incorrectly formatted.";
        }

        String password = JOptionPane.showInputDialog(null, "Please enter your password:", "Password", JOptionPane.PLAIN_MESSAGE);
        boolean isPasswordValid = setPassword(password);

        if (!isPasswordValid) {
            return "\nThe password does not meet the complexity requirements.";
        }
        return "\nThe username and password meet the requirements, and the user has been registered successfully.";
    }
    public boolean checkUserName() {
        return this.username.contains("_") && this.username.length() <= 5;
    }
    public boolean checkPasswordComplexity() {
        return this.password.length() >= 8;
    }
    public boolean getLoginDetails() {
        String userName = JOptionPane.showInputDialog(null, "Username:", "Login", JOptionPane.PLAIN_MESSAGE);
        String userPassword = JOptionPane.showInputDialog(null, "Password:", "Login", JOptionPane.PLAIN_MESSAGE);

        boolean loginStatus = loginUser(userName, userPassword);
        if (loginStatus) {
            JOptionPane.showMessageDialog(null, "\nWelcome " + this.username + " " + this.surname + ". It's great to see you again.", "Login Successful", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "\nUsername or Password is incorrect. Please try again.", "Login Failed", JOptionPane.ERROR_MESSAGE);
        }
        return loginStatus;
    }

    public boolean loginUser(String userName, String userPassword) {
        return this.username.equals(userName) && this.password.equals(userPassword);
    }
}
