/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.finalpart3;
import javax.swing.JOptionPane;
import java.util.List;
public class ShowReport {
    private List<String> developer;
    private List<String> taskNames;
    private List<String> taskID;
    private List<String> status;
    private List<Integer> duration;

    public ShowReport(List<String> developer, List<String> taskNames, List<String> taskID, List<String> status, List<Integer> duration) {
        this.developer = developer;
        this.taskNames = taskNames;
        this.taskID = taskID;
        this.status = status;
        this.duration = duration;
    }

    public void showReport() {
        StringBuilder report = new StringBuilder("Task Report:\n\n");
        for (int i = 0; i < taskNames.size(); i++) {
            report.append("Task Name: ").append(taskNames.get(i)).append("\n");
            report.append("Task ID: ").append(taskID.get(i)).append("\n");
            report.append("Developer: ").append(developer.get(i)).append("\n");
            report.append("Duration: ").append(duration.get(i)).append(" hours\n");
            report.append("Status: ").append(status.get(i)).append("\n\n");
        }

        String[] options = { "All Tasks", "Done Tasks" };
        String choice = (String) JOptionPane.showInputDialog(null, "Which tasks would you like to display?", "Task Report",
                JOptionPane.PLAIN_MESSAGE, null, options, options[0]);

        if (choice == null) {
            // User closed the dialog, return without displaying the report
            return;
        }

        if (choice.equals("Done Tasks")) {
            StringBuilder doneTasksReport = new StringBuilder("Done Tasks:\n\n");
            for (int i = 0; i < taskNames.size(); i++) {
                if (status.get(i).equalsIgnoreCase("done")) {
                    doneTasksReport.append("Task Name: ").append(taskNames.get(i)).append("\n");
                    doneTasksReport.append("Task ID: ").append(taskID.get(i)).append("\n");
                    doneTasksReport.append("Developer: ").append(developer.get(i)).append("\n");
                    doneTasksReport.append("Duration: ").append(duration.get(i)).append(" hours\n");
                    doneTasksReport.append("Status: ").append(status.get(i)).append("\n\n");
                }
            }
            JOptionPane.showMessageDialog(null, doneTasksReport.toString());
        } else {
            JOptionPane.showMessageDialog(null, report.toString());
        }
    }
}
