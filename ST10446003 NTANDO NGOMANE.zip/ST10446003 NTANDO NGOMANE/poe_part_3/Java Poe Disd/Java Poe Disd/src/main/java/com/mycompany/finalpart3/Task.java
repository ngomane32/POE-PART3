/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.finalpart3;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class Task {
    private List<String> developer;
    private List<String> taskNames;
    private List<String> taskID;
    private List<String> status;
    private List<Integer> duration;

    public Task() {
        developer = new ArrayList<>();
        taskNames = new ArrayList<>();
        taskID = new ArrayList<>();
        status = new ArrayList<>();
        duration = new ArrayList<>();
    }
public void addTask(int count) {
        for (int i = 0; i < count; i++) {
            try {
                String developerName = JOptionPane.showInputDialog("Enter the developer name for task " + (i + 1));
                String taskName = JOptionPane.showInputDialog("Enter the task name for task " + (i + 1));
                String taskID = JOptionPane.showInputDialog("Enter the task ID for task " + (i + 1));
                int taskDuration = Integer.parseInt(JOptionPane.showInputDialog("Enter the duration for task " + (i + 1)));
                String taskStatus = JOptionPane.showInputDialog("Enter the status for task " + (i + 1) + " (done, doing, to do)");

                developer.add(developerName);
                taskNames.add(taskName);
                this.taskID.add(taskID);
                duration.add(taskDuration);
                status.add(taskStatus);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Invalid duration entered. Please enter a valid number.");
                i--; // Decrement i to repeat the current iteration and prompt for input again
            }
        }

        JOptionPane.showMessageDialog(null, "Tasks added successfully!");
    }

    public int returnTotalHours() {
        int total = 0;
        for (int dur : duration) {
            total += dur;
        }
        return total;
    }

    public String searchTask(String taskName) {
        StringBuilder searchResult = new StringBuilder("Search Result:\n\n");
        boolean found = false;
        for (int i = 0; i < taskNames.size(); i++) {
            if (taskNames.get(i).equalsIgnoreCase(taskName)) {
                searchResult.append("Task Name: ").append(taskNames.get(i)).append("\n");
                searchResult.append("Task ID: ").append(taskID.get(i)).append("\n");
                searchResult.append("Developer: ").append(developer.get(i)).append("\n");
                searchResult.append("Duration: ").append(duration.get(i)).append(" hours\n");
                searchResult.append("Status: ").append(status.get(i)).append("\n\n");
                found = true;
            }
        }
        if (!found) {
            searchResult.append("Task not found.");
        }
        return searchResult.toString();
    }

    public String deleteTask(String taskName) {
        StringBuilder deleteResult = new StringBuilder();
        boolean deleted = false;
        for (int i = 0; i < taskNames.size(); i++) {
            if (taskNames.get(i).equalsIgnoreCase(taskName)) {
                taskNames.remove(i);
                taskID.remove(i);
                developer.remove(i);
                status.remove(i);
                duration.remove(i);
                deleteResult.append("Task \"").append(taskName).append("\" deleted.");
                deleted = true;
                break;
            }
        }
        if (!deleted) {
            deleteResult.append("Task not found.");
        }
        return deleteResult.toString();
    }

    public String displayLongest() {
        int longestDuration = 0;
        int longestIndex = -1;
        for (int i = 0; i < duration.size(); i++) {
            if (duration.get(i) > longestDuration) {
                longestDuration = duration.get(i);
                longestIndex = i;
            }
        }
        if (longestIndex != -1) {
            StringBuilder longestResult = new StringBuilder("Developer with Longest Duration:\n\n");
            longestResult.append("Developer: ").append(developer.get(longestIndex)).append("\n");
            longestResult.append("Task Name: ").append(taskNames.get(longestIndex)).append("\n");
            longestResult.append("Task ID: ").append(taskID.get(longestIndex)).append("\n");
            longestResult.append("Duration: ").append(duration.get(longestIndex)).append(" hours");
            return longestResult.toString();
        } else {
            return "No tasks found.";
        }
    }

    public String searchDeveloper(String devName) {
        StringBuilder searchResult = new StringBuilder("Search Result:\n\n");
        boolean found = false;
        for (int i = 0; i < developer.size(); i++) {
            if (developer.get(i).equalsIgnoreCase(devName)) {
                searchResult.append("Developer: ").append(developer.get(i)).append("\n");
                searchResult.append("Task Name: ").append(taskNames.get(i)).append("\n");
                searchResult.append("Task ID: ").append(taskID.get(i)).append("\n");
                searchResult.append("Duration: ").append(duration.get(i)).append(" hours\n");
                searchResult.append("Status: ").append(status.get(i)).append("\n\n");
                found = true;
            }
        }
        if (!found) {
            searchResult.append("Developer not found.");
        }
        return searchResult.toString();
    }

    public void updateTaskStatus(String taskName, String status) {
        for (int i = 0; i < taskNames.size(); i++) {
            if (taskNames.get(i).equalsIgnoreCase(taskName)) {
                this.status.set(i, status);
                break;
            }
        }
    }
    public List<String> getDeveloper() {
        return developer;
    }

    public List<String> getTaskNames() {
        return taskNames;
    }
    public List<String> getTaskID() {
        return taskID;
    }

    public List<String> getStatus() {
        return status;
    }

    public List<Integer> getDuration() {
        return duration;
    }
}
