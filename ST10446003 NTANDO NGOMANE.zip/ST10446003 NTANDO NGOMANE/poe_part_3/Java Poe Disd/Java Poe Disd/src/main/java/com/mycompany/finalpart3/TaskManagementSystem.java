

package com.mycompany.finalpart3;
import javax.swing.JOptionPane;

public class TaskManagementSystem {
    private Task task;
    private int totalHours;

    public TaskManagementSystem() {
        task = new Task();
        totalHours = 0;
    }

    public void start() {
        try {
            while (true) {
                Object[] options = { "Add Task", "Show Report", "Search for Task", "Delete Task",
                        "Display Developer with Longest Duration", "Search Task Assigned to Developer",
                        "Mark Task as Done", "Quit" };

                Object choice = JOptionPane.showInputDialog(null, "Select an option:", "Task Management System",
                        JOptionPane.PLAIN_MESSAGE, null, options, options[0]);

                if (choice == null || choice.equals("Quit")) {
                    // User closed the dialog or selected "Quit", exit the loop
                    break;
                }

                if (choice.equals("Add Task")) {
                    try {
                        int countTask = Integer.parseInt(JOptionPane.showInputDialog("How many tasks do you want to add?"));
                        task.addTask(countTask);
                        totalHours += task.returnTotalHours();
                    } catch (NumberFormatException e) {
                        JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid number.");
                    }
                } else if (choice.equals("Show Report")) {
                    ShowReport show = new ShowReport(task.getDeveloper(), task.getTaskNames(), task.getTaskID(),
                            task.getStatus(), task.getDuration());
                    show.showReport();
                } else if (choice.equals("Search for Task")) {
                    String taskName = JOptionPane.showInputDialog("Please enter the task name you want to search:");
                    String searchResult = task.searchTask(taskName);
                    JOptionPane.showMessageDialog(null, searchResult);
                } else if (choice.equals("Delete Task")) {
                    String taskDel = JOptionPane.showInputDialog(null, "Which task do you wish to delete:");
                    String deleteResult = task.deleteTask(taskDel);
                    JOptionPane.showMessageDialog(null, deleteResult);
                } else if (choice.equals("Display Developer with Longest Duration")) {
                    String longestResult = task.displayLongest();
                    JOptionPane.showMessageDialog(null, longestResult);
                } else if (choice.equals("Search Task Assigned to Developer")) {
                    String dev = JOptionPane.showInputDialog(null, "Please enter the developer details:");
                    String searchDevResult = task.searchDeveloper(dev);
                    JOptionPane.showMessageDialog(null, searchDevResult);
                } else if (choice.equals("Mark Task as Done")) {
                    String taskNameDone = JOptionPane.showInputDialog(null, "Which task do you want to mark as Done?");
                    task.updateTaskStatus(taskNameDone, "Done");
                    JOptionPane.showMessageDialog(null, "Task \"" + taskNameDone + "\" marked as Done.");
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "An error occurred.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        TaskManagementSystem system = new TaskManagementSystem();
        system.start();
    }
}
